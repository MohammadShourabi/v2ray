export function vlessJs(): string {
  return 'vless-js';
}
