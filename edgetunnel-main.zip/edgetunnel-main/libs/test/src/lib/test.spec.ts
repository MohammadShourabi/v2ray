import { test } from './test';

describe('test', () => {
  it('should work', () => {
    expect(test()).toEqual('test');
  });
});
